const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const fontToggle = document.getElementById("fontToggle");
const contrastToggle = document.getElementById("contrastToggle");

if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", function () {
        navLinks.classList.toggle("active");
    });
}

if (fontToggle) {
    fontToggle.addEventListener("click", function () {
        document.body.classList.toggle("big-font");
    });
}

if (contrastToggle) {
    contrastToggle.addEventListener("click", function () {
        document.body.classList.toggle("high-contrast");
    });
}

const lakeSearch = document.getElementById("lakeSearch");
const lakeCards = document.querySelectorAll(".lake-card");

if (lakeSearch) {
    lakeSearch.addEventListener("input", function () {
        const searchText = lakeSearch.value.toLowerCase();

        lakeCards.forEach(function (card) {
            const cardText = card.innerText.toLowerCase();

            if (cardText.includes(searchText)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });
}