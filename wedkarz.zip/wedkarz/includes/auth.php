<?php
session_start();

function isAdmin() {
    return isset($_SESSION["admin"]) && $_SESSION["admin"] === true;
}

function requireAdmin() {
    if (!isAdmin()) {
        header("Location: login.php");
        exit;
    }
}
?>