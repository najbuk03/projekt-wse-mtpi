<?php
$host = "db";
$user = "wedkarz";
$password = "wedkarzpass";
$database = "wedkarz";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych.");
}

$conn->set_charset("utf8mb4");
?>
