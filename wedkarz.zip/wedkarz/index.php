<?php
require_once "includes/db.php";
require_once "includes/auth.php";

$sections = [
    "start" => "Start",
    "jeziora" => "Jeziora",
    "ryby" => "Ryby",
    "ochrona" => "Ochrona",
    "oplaty" => "Opłaty",
    "sklepy" => "Sklepy",
    "kontakt" => "Kontakt"
];

$section = $_GET["section"] ?? "start";

if (!array_key_exists($section, $sections)) {
    $section = "start";
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informator dla wędkarza</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="accessibility-panel" aria-label="Ułatwienia dostępności WCAG">
    <button type="button" id="fontToggle" aria-label="Powiększ czcionkę">A+</button>
    <button type="button" id="contrastToggle" aria-label="Wysoki kontrast">◐</button>
</div>

<header class="hero">
    <nav class="navbar">
        <div class="logo">🎣 Wędkarz</div>

        <button type="button" id="menuToggle" class="menu-toggle" aria-label="Otwórz menu">
            ☰
        </button>

        <ul id="navLinks" class="nav-links">
            <?php foreach ($sections as $key => $name): ?>
                <li>
                    <a href="index.php?section=<?= htmlspecialchars($key) ?>">
                        <?= htmlspecialchars($name) ?>
                    </a>
                </li>
            <?php endforeach; ?>

            <?php if (isAdmin()): ?>
                <li><a href="admin.php">Panel</a></li>
                <li><a href="logout.php">Wyloguj</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <div class="hero-content">
        <p class="subtitle">Suwalszczyzna i okolice Augustowa</p>
        <h1>Informator dla<br>wędkarza</h1>
        <p>Praktyczny serwis o jeziorach, rybach, opłatach i sklepach wędkarskich.</p>
        <a class="button" href="index.php?section=jeziora">Zobacz jeziora</a>
    </div>
</header>

<main class="container">

<?php if ($section === "start"): ?>

    
    <section class="team-box">

    <p class="label">Zespół projektowy</p>

    <h2>Autorzy projektu</h2>

    <p class="team-description">
        Projekt „Informator dla wędkarza” został przygotowany przez zespół
        studentów WSE w Białymstoku.
    </p>

    <section class="team-grid">

        <article class="team-card">
            <h3>Kamil Żero</h3>
            <p>Treści dotyczące jezior, ryb i informacji regionalnych.</p>
        </article>

        <article class="team-card">
            <h3>Marek Najbuk</h3>
            <p>Koordynacja projektu, wdrożenie na Raspberry Pi i dokumentacja.</p>
        </article>

        <article class="team-card">
            <h3>Marek Palinowski</h3>
            <p>Implementacja HTML, CSS, JavaScript oraz testowanie aplikacji.</p>
        </article>

    </section>

    <p class="project-link">
      
    </p>

</section>

    <section class="box">
        <p class="label">Projekt zaliczeniowy</p>
        <h2>Metodologia Tworzenia Projektów Informatycznych</h2>
        <p>
            Projekt został wykonany jako dynamiczna aplikacja internetowa.
        </p>
    </section>

<?php elseif ($section === "jeziora"): ?>

    <section class="box">
        <h2>Jeziora Suwalszczyzny i okolic Augustowa</h2>

        <input
            type="text"
            id="lakeSearch"
            class="search-input"
            placeholder="Szukaj jeziora, np. Wigry, Hańcza..."
        >

        <section class="lake-grid">
            <?php
            $result = $conn->query("SELECT * FROM lakes ORDER BY name ASC");
            while ($lake = $result->fetch_assoc()):
            ?>
                <article class="lake-card">
                    <h3><?= htmlspecialchars($lake["name"]) ?></h3>
                    <p><strong>Region:</strong> <?= htmlspecialchars($lake["region"]) ?></p>
                    <p><?= nl2br(htmlspecialchars($lake["description"])) ?></p>
                    <p><strong>Ryby:</strong> <?= htmlspecialchars($lake["fish"]) ?></p>
                </article>
            <?php endwhile; ?>
        </section>
    </section>

<?php elseif ($section === "ryby"): ?>

    <section class="box">
        <h2>Atlas ryb</h2>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Gatunek</th>
                    <th>Opis</th>
                    <th>Typowe środowisko</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM fish ORDER BY name ASC");
                while ($fish = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= htmlspecialchars($fish["name"]) ?></td>
                        <td><?= htmlspecialchars($fish["description"]) ?></td>
                        <td><?= htmlspecialchars($fish["habitat"]) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php elseif ($section === "ochrona"): ?>

    <section class="box">
        <h2>Okresy ochronne</h2>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Gatunek</th>
                    <th>Przykładowy okres ochronny</th>
                    <th>Uwagi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM protection_periods ORDER BY species ASC");
                while ($row = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= htmlspecialchars($row["species"]) ?></td>
                        <td><?= htmlspecialchars($row["period"]) ?></td>
                        <td><?= htmlspecialchars($row["notes"]) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php elseif ($section === "oplaty"): ?>

    <section class="box">
        <h2>Opłaty i zezwolenia</h2>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Rodzaj opłaty</th>
                    <th>Opis</th>
                    <th>Przykładowe zastosowanie</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM fees ORDER BY fee_type ASC");
                while ($fee = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= htmlspecialchars($fee["fee_type"]) ?></td>
                        <td><?= htmlspecialchars($fee["description"]) ?></td>
                        <td><?= htmlspecialchars($fee["usage_example"]) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php elseif ($section === "sklepy"): ?>

    <section class="box">
        <h2>Sklepy wędkarskie</h2>

        <section class="shop-grid">
            <?php
            $result = $conn->query("SELECT * FROM shops ORDER BY name ASC");
            while ($shop = $result->fetch_assoc()):
            ?>
                <article class="shop-card">
                    <h3><?= htmlspecialchars($shop["name"]) ?></h3>
                    <p><strong>Lokalizacja:</strong> <?= htmlspecialchars($shop["location"]) ?></p>
                    <p><?= nl2br(htmlspecialchars($shop["description"])) ?></p>
                </article>
            <?php endwhile; ?>
        </section>
    </section>

<?php elseif ($section === "kontakt"): ?>

    <section class="box">
        <h2>Kontakt</h2>

        <?php if (isset($_GET["sent"])): ?>
            <p class="message">Wiadomość została wysłana poprawnie.</p>
        <?php endif; ?>

        <form method="post" action="send_message.php">
            <label>Imię</label>
            <input type="text" name="name" required>

            <label>Adres e-mail</label>
            <input type="email" name="email" required>

            <label>Temat</label>
            <input type="text" name="subject" required>

            <label>Treść wiadomości</label>
            <textarea name="message" required></textarea>

            <button class="button" type="submit">Wyślij wiadomość</button>
        </form>
    </section>

<?php endif; ?>


</main>

<footer>
    <p>
        Projektt: Kamil Żero, Marek Najbuk, Marek Palinowski |
        Metodologia Tworzenia Projektów Informatycznych |
        WSE Białystok 2026
    </p>
	<p>
  Pełny opis projektu dostępny jest w pliku
  <a href="Projekt_marek_najbuk_marek_palinowski_kamil_zero.pdf" target="_blank" rel="noopener noreferrer">
    Opis projektu – PDF
  </a>,
  a harmonogram prac znajduje się w pliku
  <a href="wykres_gantta_marek_najbuk_marek_palinowski_kamil_zero.xlsx" target="_blank" rel="noopener noreferrer">
    Wykres Gantta
  </a>.
</p>
</footer>

<script src="js/script.js"></script>
</body>
</html>
